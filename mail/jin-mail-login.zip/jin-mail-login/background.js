// JIN-mail 로그인 유지: 웹페이지(mail.jintar.co.kr)가 요청하면 Google 로그인 토큰을 창 없이 받아서 넘겨줌
// - 이 브라우저에 Google 계정이 로그인돼 있고 JIN-mail을 한 번 허락했으면, 창을 띄우지 않고(prompt=none) 새 토큰을 받음
// - 토큰은 요청한 JIN-mail 페이지에만 돌려주고, 이 확장은 메일을 읽거나 저장하지 않음
const ALLOWED_CLIENT = '94151073420-uuu2lscanfblmr7f7ghllcpe90e7c2uv.apps.googleusercontent.com';
const OK_ORIGINS = ['https://mail.jintar.co.kr', 'https://yoonjintar2-ctrl.github.io'];

function getToken({ scope, hint, interactive }) {
  return new Promise(res => {
    const p = { client_id: ALLOWED_CLIENT, response_type: 'token', redirect_uri: chrome.identity.getRedirectURL(), scope, prompt: interactive ? 'select_account' : 'none', include_granted_scopes: 'true' };
    if (hint) p.login_hint = hint;
    chrome.identity.launchWebAuthFlow({ url: 'https://accounts.google.com/o/oauth2/v2/auth?' + new URLSearchParams(p), interactive: !!interactive }, r => {
      if (chrome.runtime.lastError) return res({ ok: false, error: chrome.runtime.lastError.message });
      const h = new URLSearchParams(((r || '').split('#')[1]) || '');
      if (h.get('access_token')) res({ ok: true, token: h.get('access_token'), expiresIn: +h.get('expires_in') || 3599, scope: h.get('scope') || scope });
      else res({ ok: false, error: h.get('error') || 'no_token' });
    });
  });
}

chrome.runtime.onMessageExternal.addListener((msg, sender, reply) => {
  const origin = sender.origin || (sender.url && new URL(sender.url).origin);
  if (!OK_ORIGINS.includes(origin)) { reply({ ok: false, error: 'origin' }); return; }
  if (!msg || typeof msg !== 'object') { reply({ ok: false }); return; }
  if (msg.type === 'ping') { reply({ ok: true, v: chrome.runtime.getManifest().version, redirect: chrome.identity.getRedirectURL() }); return; }
  if (msg.type === 'token') { getToken({ scope: String(msg.scope || ''), hint: msg.hint ? String(msg.hint) : '', interactive: !!msg.interactive }).then(reply); return true; }
  reply({ ok: false, error: 'unknown' });
});
